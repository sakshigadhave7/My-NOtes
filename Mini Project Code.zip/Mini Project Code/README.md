# Notes App

## In this series, we will make a complete *NOTES APP* from scratch.

## Features of the App:-
1) Creating layouts.
2) Working with Recycler View.
3) Working with Sqlite Database.
4) Adding Notes to Database.
5) Updating existing Notes.
6) Deleting all Notes.
7) Swipe to delete a single note.

![custom – 23](https://user-images.githubusercontent.com/42198187/102525177-ea5fa500-40bf-11eb-9451-93349fb3d48b.png)

## Click [here](https://www.youtube.com/watch?v=T1hu96p2cok&list=PLkxod1PewIdzJ4mWcWIQvruUyEWNzZDDh) to watch complete YOUTUBE Series.
